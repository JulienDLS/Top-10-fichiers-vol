#define _XOPEN_SOURCE 500
#include <ftw.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

#include <ftw.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

/*pour obtenir la taille max du PATH*/
#include <limits.h>

/*top nombre*/
#define TOP 10

/*tableau en variable global*/
char tab_path[TOP][PATH_MAX];
intmax_t tab_size[TOP];


static int display_info(const char *fpath, const struct stat *sb, int tflag, struct FTW *ftwbuf){
    int i;
    
    if(fpath == NULL || sb == NULL || ftwbuf == NULL){
        fprintf(stderr, "error fpath == NULL || sb == NULL || ftwbuf == NULL");
        return 1;
    }

    for(i = 0; i < TOP; i++){
        if (sb->st_size > tab_size[i]) {
            strncpy(tab_path[i], fpath, PATH_MAX);
            tab_size[i] = sb->st_size;
            break;
        }
    }
    return 0;
  
}

static void init_tab_size(){
    int i = 0;
    for(i = 0; i < TOP; i++){
        tab_size[i] = 0;
    }
}

int main(int argc, char *argv[]) {
    int i;

    /*init tab_size*/
    init_tab_size();

    /*rec*/
    printf("si 0 tout est ok, fn = %d\n",\
    nftw((argc < 2) ? "." : argv[1], display_info, 0, 0) == -1); /* les deux 0 je ne m'en sert pas*/
    
    /*afftab*/
    for(i = 0; i < TOP; i++)
        printf("%-40s: %7jd (octets)\n", tab_path[i], tab_size[i]);

    return 0;
}
